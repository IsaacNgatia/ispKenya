<?php
use Illuminate\Support\ServiceProvider;

class RouterosAPIServiceProvider extends ServiceProvider
{
    public function register()
    {
        // Register the authentication services.
    }

    public function boot()
    {
        // Boot the authentication services.
    }
}